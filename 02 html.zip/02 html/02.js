function findLargestNumber(){
    const num1 = parseFloat(document.getElementById("num1").value);
    const num2 = parseFloat(document.getElementById("num2").value);
    const num3 = parseFloat(document.getElementById("num3").value);
   // I have to check the validity of the inputs
   if(isNaN(num1)|| isNaN(num2) || isNaN(num3))
   {document.getElementById("largestNumber").textContent = "Please Enter a valid input! ADD INTEGERS";} 
   else{
   const largestNumber = Math.max(num1,num2,num3);
   document.getElementById("largestNumber").textContent = `The largest number is ${largestNumber}`;
   }
}
function DetectEvenOrOdd(){
    const num = parseFloat(document.getElementById("num4").value);
  
   // I have to check the validity of the inputs
   if(isNaN(num))
   {document.getElementById("result").textContent = "Please Enter a valid input! ADD INTEGERS";} 
   else{
   const result = num % 2 === 0 ? "Even" : "Odd";
   document.getElementById("result").textContent = `The number is ${result}`;
   }
}