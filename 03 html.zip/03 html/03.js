document.getElementById("reverser").addEventListener('submit', function(event){
    event.preventDefault();
    const inputString = document.getElementById("sstr").value;
    const reverseString = reversedString(inputString);
    document.getElementById("result").innerText=`Reversed String : ${reverseString}`; 
})
function reversedString(str){
    return str.split("").reverse().join("");
}