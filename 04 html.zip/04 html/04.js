
function isPalindrome(){
    const user_input = document.getElementById("user_string").value ; 
    user_input_lower = user_input.toLowerCase();
user_input_reverse = user_input_lower.split("").reverse().join("");
if(user_input_lower === user_input_reverse){
    document.getElementById("Result").innerText = "✔ It is palindrome";
}else{
    document.getElementById("Result").innerText = "× It is not a palindrome! ";
}
}