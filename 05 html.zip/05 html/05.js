function calcFactorial(){
    const user_input = document.getElementById("user_input").value;
    let result = 1;
    for(let i = 1; i<=user_input; i++){
     result = result * i;
    }
    document.getElementById("result").innerText=`The result is ${result}`;
}